"""
Local stand-in for an OpenAI-compatible endpoint, used only to validate that
LLMClient's real (non-mock) code path — request building, auth header, retry
on 429, and response parsing — actually works end to end. This sandbox has no
internet access, so this is the closest thing to a live integration test
available here. It is NOT a substitute for testing against a real provider.
"""
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

CALL_COUNT = {"n": 0}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # keep stdout clean

    def do_POST(self):
        CALL_COUNT["n"] += 1

        # Fail the very first call with a 429 to prove the client's retry/backoff
        # logic actually engages, then succeed on the retry.
        if CALL_COUNT["n"] == 1:
            self.send_response(429)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "rate limited"}).encode())
            return

        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length))
        prompt = body["messages"][0]["content"]

        row_ids = [int(x) for x in re.findall(r'"row_id":\s*(\d+)', prompt)]
        decisions = re.findall(r'"decision":\s*"([^"]+)"', prompt)

        items = []
        for rid, decision in zip(row_ids, decisions):
            items.append({
                "row_id": rid,
                "reasoning": f"[live-mock-server] Auto-generated reasoning for row {rid} ({decision}).",
                "messages": (
                    [f"[live-mock-server] Personalized outreach draft #1 for row {rid}.",
                     f"[live-mock-server] Personalized outreach draft #2 for row {rid}."]
                    if decision == "Qualified" else []
                ),
            })

        content = json.dumps(items)
        response = {"choices": [{"message": {"content": content}}]}
        payload = json.dumps(response).encode()

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(payload)


def run(port=8765):
    server = HTTPServer(("127.0.0.1", port), Handler)
    print(f"mock server listening on {port}")
    server.serve_forever()


if __name__ == "__main__":
    run()
