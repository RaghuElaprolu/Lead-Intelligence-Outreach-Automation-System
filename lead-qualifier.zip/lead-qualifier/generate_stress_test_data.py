#!/usr/bin/env python3
"""
Generates synthetic leads purely to stress-test the pipeline at volume (the brief's
"handle 100+ leads in one run" bar). This is NOT the curated sample dataset — that's
leads.csv, hand-picked for diverse, defensible scenarios. This script exists so the
100-lead claim in the README is something we actually ran, not just asserted.
"""
import csv
import random
from datetime import date, timedelta

random.seed(42)

FIRST = ["Alex", "Jordan", "Sam", "Taylor", "Morgan", "Casey", "Riley", "Jamie", "Drew", "Avery",
         "Priya", "Wei", "Fatima", "Diego", "Noor", "Sven", "Amara", "Kenji", "Lucia", "Omar"]
LAST = ["Kim", "Silva", "Novak", "Reed", "Okafor", "Torres", "Bergman", "Nakamura", "Haddad", "Fischer",
        "Brennan", "Adeyemi", "Castillo", "Lindqvist", "Petrov", "Sato", "Mensah", "Kowalski"]
COMPANY_ROOTS = ["Bright", "Summit", "North", "Cobalt", "Lucid", "Vertex", "Anchor", "Bloom", "Kite",
                  "Harbor", "Fable", "Onyx", "Ridge", "Cascade", "Pioneer", "Delta", "Loom", "Spruce"]
COMPANY_SUFFIX = ["Labs", "Systems", "Group", "Works", "Solutions", "Partners", "Technologies", "Co", "Studio"]
INDUSTRIES = ["SaaS", "FinTech", "Healthcare", "Manufacturing", "Retail", "Logistics", "EdTech",
              "Cybersecurity", "Analytics", "Insurance", "Consulting", "Media", "Government",
              "Agriculture", "Hospitality", "Real Estate", "Energy", "Legal", "Events", "Travel",
              "Weird Unmapped Sector"]
SOURCES = ["Inbound demo request", "LinkedIn outreach", "Referral", "Webinar attendee",
           "Content download", "Sales call", ""]
SIZE_BUCKETS = [(1, 9), (10, 49), (50, 500), (501, 2000), (2001, 10000), (10001, 60000)]


def random_date_or_blank(p_blank=0.08):
    if random.random() < p_blank:
        return ""
    days_ago = random.choice([
        random.randint(0, 14), random.randint(15, 90),
        random.randint(91, 365), random.randint(366, 900),
    ])
    return (date.today() - timedelta(days=days_ago)).isoformat()


def make_lead(i: int) -> dict:
    lo, hi = random.choice(SIZE_BUCKETS)
    size = random.randint(lo, hi)
    return {
        "name": "" if random.random() < 0.05 else f"{random.choice(FIRST)} {random.choice(LAST)}",
        "company": f"{random.choice(COMPANY_ROOTS)}{random.choice(COMPANY_SUFFIX)} {i}",
        "company_size": "" if random.random() < 0.07 else size,
        "industry": "" if random.random() < 0.05 else random.choice(INDUSTRIES),
        "source": random.choice(SOURCES),
        "last_interaction_date": random_date_or_blank(),
    }


def main(n: int, out_path: str):
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "company", "company_size", "industry", "source", "last_interaction_date"])
        writer.writeheader()
        for i in range(1, n + 1):
            writer.writerow(make_lead(i))
    print(f"Wrote {n} synthetic leads to {out_path}")


if __name__ == "__main__":
    import sys
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    out = sys.argv[2] if len(sys.argv) > 2 else "data/synthetic_stress_test.csv"
    main(n, out)
